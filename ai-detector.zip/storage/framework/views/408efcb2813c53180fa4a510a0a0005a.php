<?php $__env->startSection('title', 'Features'); ?>

<?php $__env->startSection('content'); ?>

    <section class="mt-10">
        <h1 class="text-3xl font-medium">Features</h1>
        <div>
            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-8">
                    <h2 class="text-white bg-gray-800 p-5 text-3xl font-medium rounded-t-2xl"><?php echo e($feature['title']); ?></h2>
                    <p class="p-5 bg-gray-300 rounded-b-2xl">
                        <?php echo e($feature['desc']); ?>

                    </p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\Laravel Projects\ai-detector\resources\views/app/feature.blade.php ENDPATH**/ ?>